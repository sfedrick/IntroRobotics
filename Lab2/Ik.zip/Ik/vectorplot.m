function [e] = vectorplot(v)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
% or any vector that you've obtained
t = linspace(0,1,100);
e = v.*t;
end

