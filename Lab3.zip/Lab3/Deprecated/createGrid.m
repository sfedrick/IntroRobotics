function [outputArg1,outputArg2] = createGrid(dim, steps, obstacles)
%CREATEGRID builds a matrix grid representing the ___ space
% with free space denoted as a 0 and based on the 



outputArg1 = inputArg1;
outputArg2 = inputArg2;
end

