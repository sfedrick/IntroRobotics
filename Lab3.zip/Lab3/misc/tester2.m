dims = [-10, 10;
        -5, 5];
steps = 5;
discPos = [0,1];
realPos = TestPoint(discPos, steps,dims)