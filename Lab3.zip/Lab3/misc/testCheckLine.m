P = [0,0];
NewNode = [1,1];
Obstacle = [0.25 0.5 0.25 0.5];